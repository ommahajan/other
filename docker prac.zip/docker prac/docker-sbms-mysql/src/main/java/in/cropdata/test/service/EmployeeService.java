package in.cropdata.test.service;

import java.util.List;

import in.cropdata.test.model.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	void insertEmployee(Employee employee);
}