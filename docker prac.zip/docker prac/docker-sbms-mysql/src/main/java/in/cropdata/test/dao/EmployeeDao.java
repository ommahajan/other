package in.cropdata.test.dao;
import java.util.List;

import in.cropdata.test.model.Employee;


public interface EmployeeDao {
	List<Employee> getAllEmployees();
	void insertEmployee(Employee employee);
}