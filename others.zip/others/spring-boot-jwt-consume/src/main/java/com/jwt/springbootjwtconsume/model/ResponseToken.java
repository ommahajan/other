package com.jwt.springbootjwtconsume.model;

public class ResponseToken {

	private String token;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
}
