package com.jwt.springbootjwtwithjpa.dao;

import org.springframework.data.repository.CrudRepository;

import com.jwt.springbootjwtwithjpa.model.DAOUser;

public interface UserDAO extends CrudRepository<DAOUser, Integer> {

	DAOUser findByUsername(String username);
	
}
