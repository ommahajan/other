package com.jwt.springbootjwtwithjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJwtWithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJwtWithJpaApplication.class, args);
	}

}
