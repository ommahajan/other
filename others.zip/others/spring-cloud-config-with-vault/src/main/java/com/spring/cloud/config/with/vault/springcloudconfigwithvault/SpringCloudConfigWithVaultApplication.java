package com.spring.cloud.config.with.vault.springcloudconfigwithvault;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudConfigWithVaultApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudConfigWithVaultApplication.class, args);
	}

}
