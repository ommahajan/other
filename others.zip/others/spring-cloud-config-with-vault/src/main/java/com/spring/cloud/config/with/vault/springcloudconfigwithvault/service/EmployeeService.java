package com.spring.cloud.config.with.vault.springcloudconfigwithvault.service;

import java.util.List;

import com.spring.cloud.config.with.vault.springcloudconfigwithvault.model.Employee;

public interface EmployeeService {
	
	List<Employee> getAllEmployees();

}
