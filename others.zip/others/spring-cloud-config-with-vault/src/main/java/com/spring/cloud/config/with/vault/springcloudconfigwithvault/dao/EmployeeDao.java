package com.spring.cloud.config.with.vault.springcloudconfigwithvault.dao;
import com.spring.cloud.config.with.vault.springcloudconfigwithvault.model.Employee;

import java.util.List;

public interface EmployeeDao {

	List<Employee> getAllEmployees();
	
}
