package com.spring.cloud.config.with.vault.springcloudconfigwithvault;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudConfigWithVaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
