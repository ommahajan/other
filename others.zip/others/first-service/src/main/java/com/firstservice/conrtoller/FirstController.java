package com.firstservice.conrtoller;

import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employee")
public class FirstController {

	@GetMapping("/message")
//	public String test(@RequestHeader("CustomFilter") String header) {
	public String test() {
//		System.out.println("header : " + header);
		return "Hello-11 Called in First Service ";
	}
	
}
